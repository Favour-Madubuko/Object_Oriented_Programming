
/** 
 * This program illustrates that it is possible to assign values from a "narrower" data type to a "wider" data type
 * */
public class Widening {
 
  public static void main(String[] args)
  {
    int myNumber = 53;
    char myChar = '$';
    char myNewChar = (char) myNumber;
    char my2ndNewChar = (char) (myNewChar + 1);
    
    double myNumberAsDouble = myNumber;
    int myCharAsInt = myChar;
    double myCharAsDouble = myChar;
    
    System.out.println("myNumber as an int is " + myNumber + " but as a double it is " + myNumberAsDouble);
    System.out.println("myChar as a char is " + myChar + " but as an int it is " + myCharAsInt +
                       " and as a double it is " + myCharAsDouble);
    
    System.out.println();
    System.out.println("The unicode value of " + myChar + " is: " + myCharAsInt);
    System.out.println("The character with a unicode value of " + myNumber +
                       " is " + myNewChar);
    System.out.println("My second new char is " + my2ndNewChar);
    
    System.out.println("THe char with unicode value 63 is: " + (char)63);

  }
}