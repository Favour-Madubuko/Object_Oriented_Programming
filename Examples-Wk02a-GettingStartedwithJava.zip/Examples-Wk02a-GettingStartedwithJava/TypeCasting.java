
/**
 * This program illustrates what happens when we try and type cast from a "wider" variable to a "narrower" one
 * */
public class TypeCasting
{
  // declare PI as a constant
  public static final double PI = 3.14;
  
  public static void main(String[] args)
  {
    // create an int variable and cast the value of PI (stored in a constant)
    // as an int
    int intPI = (int) PI;
    
    System.out.println("PI as a double is " + PI + ", but cast to an int, it is " + intPI);

    // create a long and see what happens when we try to stuff it 
    // into an int.  We notice a variable overflow problem
    long bigValue = 3000000000L;
    int bigValueAsInt = (int) bigValue;

    System.out.println("bigValue as a long is " + bigValue + ", but cast to an int, it is " + bigValueAsInt);
  }
}