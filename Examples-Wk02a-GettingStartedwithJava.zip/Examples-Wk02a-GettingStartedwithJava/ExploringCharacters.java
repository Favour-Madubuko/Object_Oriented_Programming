
/**
 * This is a program that explores characters and also tests what happens
 * when we cast chars to ints.  Change things around and experiment!
 * 
 * @author G. Ayorkor Korsah
 **/
public class ExploringCharacters
{
  public static void main(String[] args)
  {
    // Create a variable for the characters '0' and '9'
    char myLetter0 = '0';
    char myLetter1 = '9';
    
    // Create variables for the characters 'A','B','Z','a','b' and 'z'
    char myLetter2 = 'A';
    char myLetter3 = 'B';
    char myLetter4 = 'Z';
    char myLetter5 = 'a';
    char myLetter6 = 'b';
    char myLetter7 = 'z';
    
    // Set myLetter8 to the next character after 'Z'
    char myLetter8 = 'Z' + 1;
    
    // Set myLetter9 to the character with the unicode value of 230
    char myLetter9 = 230;
    
    // Here, we convert the character to an integer so that we can find out its Unicode value.  
    // To be clear about what we are doing, we use an explicit type cast to convert the characters stored in
    // the variables myLetter0 to myLetter3 to integers.  Note, however, that because the int data type is "wider" 
    // than the char data type, this explicit typecast is not necessary.  To illustrate this, we don't use an explicit
    // type cast for variables myLetter4 to myLetter6
    int theValueOfMyLetter0 = (int) myLetter0;
    int theValueOfMyLetter1 = (int) myLetter1;
    int theValueOfMyLetter2 = (int) myLetter2;
    int theValueOfMyLetter3 = (int) myLetter3;
    int theValueOfMyLetter4 = myLetter4;
    int theValueOfMyLetter5 = myLetter5;
    int theValueOfMyLetter6 = myLetter6;
    int theValueOfMyLetter7 = myLetter7;
    
    // Let's print out the unicode values corresponding to the various letters
    System.out.println("The Unicode value of " + myLetter0 + " is: " + theValueOfMyLetter0);
    System.out.println("The Unicode value of " + myLetter1 + " is: " + theValueOfMyLetter1);
    System.out.println("The Unicode value of " + myLetter2 + " is: " + theValueOfMyLetter2);
    System.out.println("The Unicode value of " + myLetter3 + " is: " + theValueOfMyLetter3);
    System.out.println("The Unicode value of " + myLetter4 + " is: " + theValueOfMyLetter4);
    System.out.println("The Unicode value of " + myLetter5 + " is: " + theValueOfMyLetter5);
    System.out.println("The Unicode value of " + myLetter6 + " is: " + theValueOfMyLetter6);
    System.out.println("The Unicode value of " + myLetter7 + " is: " + theValueOfMyLetter7);
    System.out.println("The character after 'Z' is " + myLetter8);
    System.out.println("The character with unicode value " + (int) myLetter9 + " is " + myLetter9);
  }
}