import java.util.Scanner;

/**
 * A program to illustrate the lowercase(), uppercase() and indexOf()
 * methods of the String class.
 * 
 * @author Ayorkor Korsah
 */
public class StringFun2
{
  public static void main(String[] args)
  {
    String word, lowerCase, upperCase, substring;
    int substringLoc;
    int length;
    
    Scanner input = new Scanner(System.in);
    System.out.print("Hello.  Give me a word, and I will tell you some things about it. ");
    word = input.next();
    
    lowerCase = word.toLowerCase();
    upperCase = word.toUpperCase();
    
    System.out.print("Lower and upper case versions are, respectively: ");
    System.out.println(lowerCase + " and " + upperCase);
    
    System.out.print("Give me a substring to search for: ");
    substring = input.next();
    substringLoc = word.indexOf(substring);
   
    if (substringLoc >= 0) {
      System.out.print("The index of the first occurrence of \"" +
                       substring + "\" in \"" + word + "\" is: ");
      System.out.println(substringLoc); 
    }
    else
      System.out.print("\"" + substring + "\" does not occur in \"" +
                       word + "\"");
  }
}