import java.util.Scanner;

/**
 * A program to illustrate the matches() function of strings.
 * 
 * @author Ayorkor Korsah
 */
public class StringFun3
{
  public static void main(String[] args)
  {
    String word;
    String singleDigitPattern = "\\d";
    String allDigitPattern = "[\\d]+";
    String decimalPattern = "[\\d]*\\.[\\d]*";
    String commaNumberPattern = "[\\d]*,[\\d]*";
    String lettersOnlyPattern = "[a-zA-Z]*";
    String consonantsOnlyPattern = "[a-zA-Z&&[^aeiouAEIOU]]+";
    
    Scanner input = new Scanner(System.in);
    System.out.print("Hello.  Give me a word, and I will tell you some things about it. ");
    word = input.next();
    
    if (word.matches(singleDigitPattern))
      System.out.println(word + " is a single digit.");
    
    if (word.matches(allDigitPattern))
      System.out.println(word + " is all digits.");
    
    if (word.matches(decimalPattern))
      System.out.println(word + " is a number with a decimal point.");
    
    if (word.matches(lettersOnlyPattern))
      System.out.println(word + " has only letters.");
    
    if (word.matches(consonantsOnlyPattern))
      System.out.println(word + " has only consonants.");
    
    if (word.matches(commaNumberPattern))
      System.out.println(word + 
                         " is a number with a comma insted of the decimal point, like they write in France.");
    
  }
}