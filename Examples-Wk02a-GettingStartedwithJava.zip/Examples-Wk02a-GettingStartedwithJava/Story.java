
import java.util.Scanner;

/**
 * A program to illustrate some of the functionality of strings.
 * 
 * @author Ayorkor Korsah
 */
public class Story
{
  
  public static void main(String[] args)
  {
    // A variable to store the story we're going to write
    String story;
    
    // variables for the various input from the user.
    String name, nickname, profession, gender;
    int age;
    
    Scanner input = new Scanner(System.in);
    
    System.out.println("Hello, I am going to write a little story about you.");
    
    System.out.print("Please tell me your name: ");
    name = input.nextLine();
    
    System.out.print("What do you like to be called? ");
    nickname = input.nextLine();
    
    System.out.print("How old are you? ");
    age = input.nextInt();
    
    System.out.print("Are you a boy or a girl, a man or a woman? ");
    gender = input.next();
    
    System.out.print("And what is your profession? ");
    profession = input.next();
    
    // create the story by concatenating strings
    story = (name + " is " + age + " years old, " +
             "and likes to be called " + nickname + ". " +
             nickname + " is a " + gender + ". " +
             nickname + " is a " + profession + ". ");
    
    System.out.println("Here is my story: ");
    System.out.println(story);
    System.out.println("The end!");
  }
}