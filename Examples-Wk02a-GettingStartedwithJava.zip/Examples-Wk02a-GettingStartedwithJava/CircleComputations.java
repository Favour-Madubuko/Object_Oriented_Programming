
import java.util.Scanner;

// This is a program to compute the area and circumference of a circle 
public class CircleComputations {
  
  // define a named costant to hold the value of PI
  public static final double PI = 22.0/7;
  
  public static void main(String[] args) {
    
    Scanner keyboard = new Scanner (System.in);
    System.out.println("I can compute the area and circumference of a circle.");
    
    // Note that PI is a constant, and its value cannot be changed.  If you uncomment
    // the line of code below which tries to assign a value to PI, you will get a compilation error
    //PI = 3.14;
    
    System.out.println("The value I use for PI is: " + PI);
    
    System.out.print("Please enter radius: ");
    double radius = keyboard.nextDouble();
    
    double circumference = 2*PI*radius;
    double area =PI*radius*radius;
    
    System.out.println("The circumference is " + circumference);
    System.out.println("The area is " + area);
  }
}
    