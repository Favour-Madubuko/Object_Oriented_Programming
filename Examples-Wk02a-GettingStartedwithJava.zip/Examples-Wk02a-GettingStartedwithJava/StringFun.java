import java.util.Scanner;

/**
 * A program to illustrate some of the functionality of strings.
 * 
 * @author Ayorkor Korsah
 */
public class StringFun
{
  public static void main(String[] args)
  {
    String phrase, middlePart;
    char firstLetter, lastLetter;
    int length;
    
    Scanner input = new Scanner(System.in);
    System.out.print("Hello.  Give me a phrase, and I will tell you some things about it. ");
    phrase = input.nextLine();
    
    length = phrase.length();
    firstLetter = phrase.charAt(0);
    lastLetter = phrase.charAt(length-1);
    
    System.out.println(phrase + " has " + length + " characters.");
    System.out.print("It starts with " + firstLetter + ", ");
    System.out.println("and ends with " + lastLetter + ".");

    if (length > 2){
      middlePart = phrase.substring(1, length-1);
      System.out.println("Without the first and last letters, the word is: " +
                         middlePart);
    }
    
    System.out.println("So sorry that I can't tell you its meaning!");
  }
}