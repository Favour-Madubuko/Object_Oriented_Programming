
import java.util.Scanner;

/**
 * This is an improvement of the program in CountWords.java, that
 * attempts to count the number of words in a sentence.
 * This version works even if the user enters multiple spaces between each word.
 * It still has issues if the user starts the sentence with spaces.
 * See CountWords3.java for a further improved version.
 * 
 * @author G. Ayorkor Korsah
 */
public class CountWords2
{
  public static void main(String[] args)
  {
    String userInput;
    int length, position, numWords;
    char currentChar;
    boolean lastWasSpace = false;
    Scanner keyboard = new Scanner(System.in);
    
    System.out.println("Write a sentence or a paragraph, and I'll tell you " +
                       "how many words it has.");
    userInput = keyboard.nextLine();
    length = userInput.length();
    
    position = 0;
    numWords = 0;
    while(position < length){
      currentChar = userInput.charAt(position);
      
      if (Character.isWhitespace(currentChar)){
        if (position > 0 && lastWasSpace==false){
          numWords++;
        }
        
        lastWasSpace = true;
      }
      else if (position == length-1){
        numWords++;
      }
      else {
        lastWasSpace = false;
      }
      
      position++;
    }
    System.out.println("The sentence you entered has " + numWords + " words.");
  }
}