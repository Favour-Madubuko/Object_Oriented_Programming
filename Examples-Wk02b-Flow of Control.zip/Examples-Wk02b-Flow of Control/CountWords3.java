
import java.util.Scanner;

/**
 * This is an improvement of the program in CountWords2.java, that
 * attempts to count the number of words in a sentence.
 * This version works even if the user enters multiple spaces between each word
 * or if they start the sentence with spaces.  It still has a small issue in that
 * if the user enters a space before a punctuation mark, it counts the punctuation
 * mark as a separate word.
 * 
 * @author G. Ayorkor Korsah
 */
public class CountWords3
{
  public static void main(String[] args)
  {
    String userInput;
    int length, position, numWords;
    char currentChar;
    boolean lastWasSpace = false;
    Scanner keyboard = new Scanner(System.in);
    
    System.out.println("Write a sentence or a paragraph, and I'll tell you " +
                       "how many words it has.");
    userInput = keyboard.nextLine();
    length = userInput.length();
    
    position = 0;
    numWords = 0;
    while(position < length){
      currentChar = userInput.charAt(position);
      
      if (Character.isWhitespace(currentChar)){
        if (position > 0 && !lastWasSpace){
          numWords++;
        }
        
        lastWasSpace = true;
      }
      else if (position == length-1){
        numWords++;
      }
      else {
        lastWasSpace = false;
      }
      
      position++;
    }
    System.out.println("The sentence you entered has " + numWords + " words.");
  }
}