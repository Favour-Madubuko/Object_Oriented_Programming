import java.util.Scanner;

public class MultiplicationTable1 {
 
  public static final int MAX = 10;
  
  public static void main(String[] args){
    
    System.out.println("I will print out a multiplication table for all numbers from 1 to " + MAX);
    int x, n, product;
    
    x = 1;
    while (x <= MAX) {
      n = 1;
      // print out a row of products corresponding to the current x
      while (n <= MAX) {
        product = x * n;
        System.out.print(product + "\t");
        n++;
      }
      
      System.out.println(); // go to the next line
      x++;
    }
    
    System.out.println("We're done!");
  }
}