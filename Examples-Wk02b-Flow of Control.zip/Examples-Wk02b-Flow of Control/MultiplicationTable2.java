import java.util.Scanner;

public class MultiplicationTable2 {
 
  public static final int MAX = 12;
  
  public static void main(String[] args){
    
    System.out.println("I will print out a multiplication table for all numbers from 1 to " + MAX);
    int x, n, product;
    
    for (x=1; x <= MAX; x++){
      // print out a row of products corresponding to the current x
      for (n=1; n<=MAX; n++){
        product = x * n;
        System.out.print(product + "\t");
      }      
      System.out.println(); // go to the next line
    }
    
    System.out.println("We're done!");
  }
}